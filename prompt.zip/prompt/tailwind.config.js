module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {
      fontFamily: {
        vietnam: ["be vietnam pro", "san-serif"],
      },
    },
  },
  plugins: [],
};
